import Foundation
import XCTest
@testable import SharedCore

final class SessionMetricsTests: XCTestCase {
    func testMetricsKeepUnobservedTimeSeparate() {
        let start = Date(timeIntervalSince1970: 0)
        let sessionID = UUID()
        let events = [
            FocusEvent(
                sessionID: sessionID,
                timestamp: start.addingTimeInterval(10),
                source: .visionAI,
                level: .focused
            ),
            FocusEvent(
                sessionID: sessionID,
                timestamp: start.addingTimeInterval(22),
                source: .visionAI,
                level: .distracted
            )
        ]

        let value = SessionMetrics.breakdown(events: events, from: start, to: start.addingTimeInterval(40))
        XCTAssertEqual(value.focusedSeconds, 12)
        XCTAssertEqual(value.distractedSeconds, 18)
        XCTAssertEqual(value.unknownSeconds, 10)
        XCTAssertEqual(value.coverage, 0.75)
    }

    func testNonVisionEventsDoNotBecomeObservedTime() {
        let start = Date(timeIntervalSince1970: 0)
        let event = FocusEvent(
            sessionID: UUID(),
            timestamp: start.addingTimeInterval(5),
            source: .screenTimeShield,
            level: .distracted
        )
        let value = SessionMetrics.breakdown(events: [event], from: start, to: start.addingTimeInterval(30))
        XCTAssertEqual(value.unknownSeconds, 30)
        XCTAssertEqual(value.observedSeconds, 0)
    }
}

