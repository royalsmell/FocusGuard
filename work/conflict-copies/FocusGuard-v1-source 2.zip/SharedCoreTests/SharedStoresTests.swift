import Foundation
import XCTest
@testable import SharedCore

final class SharedStoresTests: XCTestCase {
    func testEventStoreWritesAndDrainsOnlyRequestedSession() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let store = SharedEventStore(containerURL: root)
        let firstID = UUID()
        let secondID = UUID()
        try await store.record(FocusEvent(sessionID: firstID, source: .visionAI, level: .focused))
        try await store.record(FocusEvent(sessionID: secondID, source: .visionAI, level: .distracted))

        let first = try await store.drain(sessionID: firstID)
        XCTAssertEqual(first.count, 1)
        XCTAssertEqual(first.first?.level, .focused)
        let second = try await store.drain(sessionID: secondID)
        XCTAssertEqual(second.count, 1)
    }

    func testSessionRepositoryRoundTripsActiveAndHistory() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        let repository = SessionRepository(containerURL: root)
        let session = FocusSession(
            goal: "完成设计稿",
            plannedEnd: .now.addingTimeInterval(1_500),
            mode: .hybridAI
        )
        try await repository.upsert(session)
        let loaded = try await repository.loadSessions()
        XCTAssertEqual(loaded.first?.id, session.id)

        let context = ActiveSessionContext(
            sessionID: session.id,
            goal: session.goal,
            startedAt: session.plannedStart,
            endsAt: session.plannedEnd,
            mode: session.mode,
            provider: .suggested
        )
        try await repository.saveActive(context)
        let active = try await repository.loadActive()
        XCTAssertEqual(active, context)
        try await repository.clearActive()
        let cleared = try await repository.loadActive()
        XCTAssertNil(cleared)
    }

    func testRetentionRemovesOnlyExpiredFiles() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let oldData = Data([1, 2, 3])
        let path = try ThumbnailStore.write(jpegData: oldData, sessionID: UUID(), containerURL: root)
        let url = root.appendingPathComponent(path)
        try FileManager.default.setAttributes(
            [.modificationDate: Date(timeIntervalSince1970: 0)],
            ofItemAtPath: url.path
        )
        let removed = try ThumbnailStore.removeExpired(olderThan: 30, now: Date(), containerURL: root)
        XCTAssertEqual(removed, 1)
        XCTAssertFalse(FileManager.default.fileExists(atPath: url.path))
    }
}

