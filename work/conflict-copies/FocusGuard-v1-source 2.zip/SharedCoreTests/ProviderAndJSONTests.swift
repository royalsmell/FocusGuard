import Foundation
import XCTest
@testable import SharedCore

final class ProviderAndJSONTests: XCTestCase {
    func testProviderBuildsChatCompletionsURL() {
        let provider = ProviderConfig(
            name: "Test",
            baseURL: URL(string: "https://example.com/v1")!,
            model: "vision"
        )
        XCTAssertEqual(provider.chatCompletionsURL.absoluteString, "https://example.com/v1/chat/completions")

        let trailingSlash = ProviderConfig(
            name: "Test",
            baseURL: URL(string: "https://example.com/v1/")!,
            model: "vision"
        )
        XCTAssertEqual(trailingSlash.chatCompletionsURL.absoluteString, "https://example.com/v1/chat/completions")
    }

    func testJSONFenceIsRemoved() {
        let input = """
        ```json
        {"level":"focused"}
        ```
        """
        XCTAssertEqual(OpenAICompatibleVisionService.cleanJSON(input), #"{"level":"focused"}"#)
    }
}
