import FamilyControls
import ManagedSettings
import SharedCore

final class ShieldActionExtension: ShieldActionDelegate {
    override func handle(
        action: ShieldAction,
        for application: ApplicationToken,
        completionHandler: @escaping (ShieldActionResponse) -> Void
    ) {
        recordBlockedAttempt()
        completionHandler(.close)
    }

    override func handle(
        action: ShieldAction,
        for webDomain: WebDomainToken,
        completionHandler: @escaping (ShieldActionResponse) -> Void
    ) {
        recordBlockedAttempt()
        completionHandler(.close)
    }

    override func handle(
        action: ShieldAction,
        for category: ActivityCategoryToken,
        completionHandler: @escaping (ShieldActionResponse) -> Void
    ) {
        recordBlockedAttempt()
        completionHandler(.close)
    }

    private func recordBlockedAttempt() {
        guard let active = ActiveSessionSnapshot.load() else { return }
        try? ExtensionEventWriter.record(
            FocusEvent(
                sessionID: active.sessionID,
                source: .screenTimeShield,
                level: .distracted,
                confidence: 1,
                reason: "尝试打开专注期间已屏蔽的内容。",
                reminder: "回到这次的专注目标。"
            )
        )
    }
}
