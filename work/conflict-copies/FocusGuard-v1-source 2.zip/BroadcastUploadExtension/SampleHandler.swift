import CoreMedia
import Foundation
import ImageIO
import ReplayKit
import SharedCore
import UniformTypeIdentifiers
import UserNotifications

final class SampleHandler: RPBroadcastSampleHandler, @unchecked Sendable {
    private let repository = SessionRepository()
    private let eventStore = SharedEventStore()
    private let imageProcessor = BroadcastImageProcessor()
    private let lock = NSLock()

    private var activeContext: ActiveSessionContext?
    private var lastSampleAt: Date?
    private var lastAnalyzedAt: Date?
    private var lastHash: UInt64?
    private var recentLevels: [FocusLevel] = []
    private var interventionEngine = InterventionEngine()
    private var isAnalyzing = false

    override func broadcastStarted(withSetupInfo setupInfo: [String: NSObject]?) {
        Task { [weak self] in
            guard let self, let active = try? await repository.loadActive() else { return }
            lock.withLock { activeContext = active }
            try? await eventStore.record(
                FocusEvent(
                    sessionID: active.sessionID,
                    source: .broadcast,
                    level: .unknown,
                    reason: "AI 屏幕广播已开始。"
                )
            )
        }
    }

    override func broadcastPaused() {
        recordBroadcastState("AI 屏幕广播已暂停。")
    }

    override func broadcastResumed() {
        recordBroadcastState("AI 屏幕广播已恢复。")
    }

    override func broadcastFinished() {
        recordBroadcastState("AI 屏幕广播已停止，会话继续使用 Screen Time 模式。")
        notify(
            title: "AI 守望已停止",
            body: "应用屏蔽仍会持续到专注结束；这段时间会记为未观测。",
            sound: false
        )
    }

    override func processSampleBuffer(
        _ sampleBuffer: CMSampleBuffer,
        with sampleBufferType: RPSampleBufferType
    ) {
        guard sampleBufferType == .video, let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        let now = Date()

        let snapshot: ActiveSessionContext? = lock.withLock {
            guard let activeContext,
                  now < activeContext.endsAt,
                  !isAnalyzing,
                  now.timeIntervalSince(lastSampleAt ?? .distantPast) >= 12 else { return nil }
            lastSampleAt = now
            return activeContext
        }
        guard let active = snapshot else { return }
        guard let authoritative = ActiveSessionSnapshot.load(),
              authoritative.sessionID == active.sessionID else {
            lock.withLock { activeContext = nil }
            return
        }

        let hash = imageProcessor.dHash(pixelBuffer: pixelBuffer)
        let shouldAnalyze: Bool = lock.withLock {
            let force = now.timeIntervalSince(lastAnalyzedAt ?? .distantPast) >= 60
            let changed: Bool
            if let hash, let lastHash {
                changed = DHash64.distance(hash, lastHash) >= 8
            } else {
                changed = true
            }
            if !force && !changed { return false }
            lastHash = hash
            lastAnalyzedAt = now
            isAnalyzing = true
            return true
        }
        guard shouldAnalyze,
              let jpeg = imageProcessor.jpeg(pixelBuffer: pixelBuffer, longEdge: 1_024, quality: 0.55) else {
            lock.withLock { isAnalyzing = false }
            return
        }

        Task { [weak self] in
            await self?.analyze(jpeg: jpeg, active: active, timestamp: now)
        }
    }

    private func analyze(jpeg: Data, active: ActiveSessionContext, timestamp: Date) async {
        defer { lock.withLock { isAnalyzing = false } }
        guard let provider = active.provider,
              let key = try? KeychainStore.load(
                account: provider.id.uuidString,
                accessGroup: resolvedKeychainAccessGroup
              ),
              let key, !key.isEmpty else {
            await recordUnknown(active: active, timestamp: timestamp, reason: "未配置可用的 AI 密钥。")
            return
        }

        let levels = lock.withLock { recentLevels }
        let service = OpenAICompatibleVisionService(provider: provider, apiKey: key)
        let started = ContinuousClock.now
        do {
            let judgment = try await service.classifyFrame(
                FrameAnalysisInput(goal: active.goal, jpegData: jpeg, recentLevels: levels)
            )
            let latency = Int(ContinuousClock.now - started).milliseconds
            let intervention = lock.withLock { () -> Intervention in
                recentLevels.append(judgment.level)
                recentLevels = Array(recentLevels.suffix(3))
                return interventionEngine.register(judgment, at: timestamp)
            }
            let shouldSaveThumbnail: Bool
            if case .audible = intervention {
                shouldSaveThumbnail = true
            } else {
                shouldSaveThumbnail = false
            }
            let thumbnailPath: String?
            if shouldSaveThumbnail,
               let thumbnail = makeThumbnail(from: jpeg) {
                thumbnailPath = try? ThumbnailStore.write(jpegData: thumbnail, sessionID: active.sessionID)
            } else {
                thumbnailPath = nil
            }
            try? await eventStore.record(
                FocusEvent(
                    sessionID: active.sessionID,
                    timestamp: timestamp,
                    source: .visionAI,
                    level: judgment.level,
                    confidence: judgment.confidence,
                    reason: judgment.reason,
                    reminder: judgment.reminder,
                    latencyMilliseconds: latency,
                    thumbnailRelativePath: thumbnailPath
                )
            )
            deliver(intervention)
        } catch {
            await recordUnknown(active: active, timestamp: timestamp, reason: "AI 分析暂时不可用。")
        }
    }

    private func recordUnknown(active: ActiveSessionContext, timestamp: Date, reason: String) async {
        try? await eventStore.record(
            FocusEvent(
                sessionID: active.sessionID,
                timestamp: timestamp,
                source: .visionAI,
                level: .unknown,
                reason: reason
            )
        )
    }

    private func makeThumbnail(from jpeg: Data) -> Data? {
        guard let source = CGImageSourceCreateWithData(jpeg as CFData, nil) else { return nil }
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceThumbnailMaxPixelSize: 320,
            kCGImageSourceCreateThumbnailWithTransform: true
        ]
        guard let image = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else { return nil }
        let data = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(
            data,
            UTType.jpeg.identifier as CFString,
            1,
            nil
        ) else { return nil }
        CGImageDestinationAddImage(
            destination,
            image,
            [kCGImageDestinationLossyCompressionQuality: 0.5] as CFDictionary
        )
        guard CGImageDestinationFinalize(destination) else { return nil }
        return data as Data
    }

    private func deliver(_ intervention: Intervention) {
        switch intervention {
        case .none:
            return
        case .silent(let message):
            notify(title: "轻轻回到目标", body: message, sound: false)
        case .audible(let message):
            notify(title: "专注守望提醒", body: message, sound: true)
        }
    }

    private func notify(title: String, body: String, sound: Bool) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.categoryIdentifier = SharedConstants.notificationCategory
        content.sound = sound ? .default : nil
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request)
    }

    private func recordBroadcastState(_ reason: String) {
        Task { [weak self] in
            guard let self, let active = lock.withLock({ activeContext }) else { return }
            try? await eventStore.record(
                FocusEvent(
                    sessionID: active.sessionID,
                    source: .broadcast,
                    level: .unknown,
                    reason: reason
                )
            )
        }
    }

    private var resolvedKeychainAccessGroup: String? {
        Bundle.main.object(forInfoDictionaryKey: "FocusGuardKeychainAccessGroup") as? String
    }
}

private extension Duration {
    var milliseconds: Int64 {
        let components = self.components
        return components.seconds * 1_000 + components.attoseconds / 1_000_000_000_000_000
    }
}
