import FamilyControls
import Foundation
import ManagedSettings
import SharedCore

extension ManagedSettingsStore.Name {
    static let focusGuard = Self("focusguard")
}

enum ScreenTimeSharedStore {
    static let managedStore = ManagedSettingsStore(named: .focusGuard)

    static func save(_ selection: FamilyActivitySelection) throws {
        guard let defaults = UserDefaults(suiteName: SharedConstants.appGroupIdentifier) else { return }
        defaults.set(try PropertyListEncoder().encode(selection), forKey: SharedConstants.selectionDefaultsKey)
    }

    static func load() -> FamilyActivitySelection {
        guard let defaults = UserDefaults(suiteName: SharedConstants.appGroupIdentifier),
              let data = defaults.data(forKey: SharedConstants.selectionDefaultsKey),
              let selection = try? PropertyListDecoder().decode(FamilyActivitySelection.self, from: data) else {
            return FamilyActivitySelection()
        }
        return selection
    }

    static func applyShield(for selection: FamilyActivitySelection? = nil) {
        let selection = selection ?? load()
        managedStore.shield.applications = selection.applicationTokens.isEmpty
            ? nil
            : selection.applicationTokens
        managedStore.shield.applicationCategories = selection.categoryTokens.isEmpty
            ? nil
            : .specific(selection.categoryTokens)
        managedStore.shield.webDomains = selection.webDomainTokens.isEmpty
            ? nil
            : selection.webDomainTokens
        managedStore.shield.webDomainCategories = selection.categoryTokens.isEmpty
            ? nil
            : .specific(selection.categoryTokens)
    }

    static func clearShield() {
        managedStore.clearAllSettings()
    }
}

