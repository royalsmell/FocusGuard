# 专注守望（FocusGuard）

一款面向 iPhone 与 iPad 的本地优先专注助手。它使用 Screen Time 屏蔽用户主动选择的分心内容，并在用户明确开启 ReplayKit 屏幕广播后，用自带 API Key 的视觉模型判断专注状态。

## 已实现

- iOS 18+ SwiftUI 通用 App，包含首页、进行中会话、历史、复盘和设置。
- Family Controls 选择器、Device Activity 日程、Managed Settings Shield 与拦截事件。
- ReplayKit Broadcast Upload Extension：12 秒采样、dHash 去重、60 秒强制分析、20 秒请求超时。
- OpenAI-compatible 视觉分析、目标校验和会话复盘；API Key 存在共享 Keychain。
- 连续三次走神静默提醒、连续两次分心有声提醒和各自冷却时间。
- 只保存分心缩略图，30 天清理；原始帧不落盘。
- App Group 事件队列、异常恢复、自动解除 Shield、未观测时间独立统计。
- 锁屏与 Dynamic Island 倒计时 Live Activity。

## 本机准备

1. 从 App Store 或 Apple Developer 下载并安装完整 Xcode。
2. 执行 `sudo xcode-select -s /Applications/Xcode.app/Contents/Developer`。
3. 复制 `Config/Local.xcconfig.example` 为 `Config/Local.xcconfig`，填入 Apple Developer Team ID。
4. 在 Apple Developer 账户中为主 App 与三个 Screen Time 扩展启用 Family Controls（development），并为相关 Target 配置 App Group 与 Keychain Sharing。
5. 运行 `xcodegen generate`，用 Xcode 打开 `FocusGuard.xcodeproj`。

Family Controls、跨 App ReplayKit 广播与 Shield 必须在 iOS 18+ 真机验证；模拟器只能用于普通界面与共享核心测试。

## 验证命令

```sh
swift run CoreChecks
xcodegen generate
xcodebuild -project FocusGuard.xcodeproj -scheme FocusGuard -destination 'generic/platform=iOS' build
```

最后一条命令需要完整 Xcode和有效签名配置。项目不包含任何第三方运行时依赖，也不包含 Vigil 的源码、提示词或素材。

