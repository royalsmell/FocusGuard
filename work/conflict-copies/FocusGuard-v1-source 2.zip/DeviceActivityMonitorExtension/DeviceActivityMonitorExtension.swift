import DeviceActivity
import Foundation
import SharedCore

final class DeviceActivityMonitorExtension: DeviceActivityMonitor {
    override func intervalDidStart(for activity: DeviceActivityName) {
        super.intervalDidStart(for: activity)
        guard activity.rawValue == SharedConstants.focusActivityName else { return }
        ScreenTimeSharedStore.applyShield()
        recordSystemEvent(reason: "专注日程开始，已启用应用遮挡。")
    }

    override func intervalDidEnd(for activity: DeviceActivityName) {
        super.intervalDidEnd(for: activity)
        guard activity.rawValue == SharedConstants.focusActivityName else { return }
        ScreenTimeSharedStore.clearShield()
        recordSystemEvent(reason: "专注日程结束，已解除应用遮挡。")
    }

    private func recordSystemEvent(reason: String) {
        guard let active = ActiveSessionSnapshot.load() else { return }
        let event = FocusEvent(
            sessionID: active.sessionID,
            source: .system,
            level: .unknown,
            reason: reason
        )
        try? ExtensionEventWriter.record(event)
    }
}
