import Foundation

public struct ProviderConfig: Codable, Identifiable, Equatable, Sendable {
    public let id: UUID
    public var name: String
    public var baseURL: URL
    public var model: String

    public init(id: UUID = UUID(), name: String, baseURL: URL, model: String) {
        self.id = id
        self.name = name
        self.baseURL = baseURL
        self.model = model
    }

    public var chatCompletionsURL: URL {
        let trimmed = baseURL.absoluteString.replacingOccurrences(
            of: #"/+$"#,
            with: "",
            options: .regularExpression
        )
        let normalized = URL(string: trimmed) ?? baseURL
        if normalized.path.lowercased().hasSuffix("/chat/completions") {
            return normalized
        }
        if normalized.path.lowercased().hasSuffix("/v1") {
            return normalized.appendingPathComponent("chat/completions")
        }
        return normalized.appendingPathComponent("v1/chat/completions")
    }

    public static let suggested = ProviderConfig(
        name: "OpenAI Compatible",
        baseURL: URL(string: "https://api.openai.com/v1")!,
        model: "gpt-4o-mini"
    )
}
