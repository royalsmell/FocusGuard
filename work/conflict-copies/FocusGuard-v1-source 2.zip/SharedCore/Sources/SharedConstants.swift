import Foundation

public enum SharedConstants {
    public static let appGroupIdentifier = "group.com.huangjiawen.focusguard"
    public static let keychainAccessGroup = "$(AppIdentifierPrefix)com.huangjiawen.focusguard.shared"
    public static let focusActivityName = "com.huangjiawen.focusguard.session"
    public static let providerDefaultsKey = "ai.provider.configuration"
    public static let selectionDefaultsKey = "screen-time.selection"
    public static let notificationCategory = "FOCUS_GUARD_ALERT"
    public static let broadcastExtensionBundleIdentifier = "com.huangjiawen.focusguard.BroadcastUpload"
}

public enum SharedEnvironment {
    public static func containerURL(fileManager: FileManager = .default) -> URL {
        if let groupURL = fileManager.containerURL(
            forSecurityApplicationGroupIdentifier: SharedConstants.appGroupIdentifier
        ) {
            return groupURL
        }

        let fallback = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("FocusGuard", isDirectory: true)
        try? fileManager.createDirectory(at: fallback, withIntermediateDirectories: true)
        return fallback
    }
}

