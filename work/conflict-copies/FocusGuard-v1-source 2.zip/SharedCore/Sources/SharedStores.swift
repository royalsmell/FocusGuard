import Foundation

public enum ActiveSessionSnapshot {
    public static func load(containerURL: URL = SharedEnvironment.containerURL()) -> ActiveSessionContext? {
        let url = containerURL.appendingPathComponent("active-session.json")
        guard let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder.focusGuard.decode(ActiveSessionContext.self, from: data)
    }
}

public enum ExtensionEventWriter {
    public static func record(
        _ event: FocusEvent,
        containerURL: URL = SharedEnvironment.containerURL()
    ) throws {
        let rootURL = containerURL.appendingPathComponent("events", isDirectory: true)
        try FileManager.default.createDirectory(at: rootURL, withIntermediateDirectories: true)
        let url = rootURL.appendingPathComponent("\(event.sessionID.uuidString)-\(event.id.uuidString).json")
        try JSONEncoder.focusGuard.encode(event).write(to: url, options: .atomic)
        #if os(iOS)
        try? FileManager.default.setAttributes(
            [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication],
            ofItemAtPath: url.path
        )
        #endif
    }
}

public actor SharedEventStore {
    private let rootURL: URL
    private let decoder: JSONDecoder

    public init(containerURL: URL = SharedEnvironment.containerURL()) {
        self.rootURL = containerURL.appendingPathComponent("events", isDirectory: true)
        self.decoder = JSONDecoder.focusGuard
    }

    public func record(_ event: FocusEvent) throws {
        try ExtensionEventWriter.record(event, containerURL: rootURL.deletingLastPathComponent())
    }

    public func drain(sessionID: UUID) throws -> [FocusEvent] {
        guard FileManager.default.fileExists(atPath: rootURL.path) else { return [] }
        let prefix = sessionID.uuidString + "-"
        let files = try FileManager.default.contentsOfDirectory(
            at: rootURL,
            includingPropertiesForKeys: nil
        ).filter { $0.lastPathComponent.hasPrefix(prefix) }

        var events: [FocusEvent] = []
        for file in files {
            if let data = try? Data(contentsOf: file), let event = try? decoder.decode(FocusEvent.self, from: data) {
                events.append(event)
            }
            try? FileManager.default.removeItem(at: file)
        }
        return events.sorted { $0.timestamp < $1.timestamp }
    }
}

public actor SessionRepository {
    private let sessionsURL: URL
    private let activeURL: URL
    private let encoder = JSONEncoder.focusGuard
    private let decoder = JSONDecoder.focusGuard

    public init(containerURL: URL = SharedEnvironment.containerURL()) {
        self.sessionsURL = containerURL.appendingPathComponent("sessions.json")
        self.activeURL = containerURL.appendingPathComponent("active-session.json")
    }

    public func loadSessions() throws -> [FocusSession] {
        guard FileManager.default.fileExists(atPath: sessionsURL.path) else { return [] }
        return try decoder.decode([FocusSession].self, from: Data(contentsOf: sessionsURL))
            .sorted { $0.plannedStart > $1.plannedStart }
    }

    public func upsert(_ session: FocusSession) throws {
        var sessions = (try? loadSessions()) ?? []
        sessions.removeAll { $0.id == session.id }
        sessions.append(session)
        sessions.sort { $0.plannedStart > $1.plannedStart }
        try encoder.encode(sessions).write(to: sessionsURL, options: .atomic)
    }

    public func deleteAll() throws {
        try? FileManager.default.removeItem(at: sessionsURL)
        try? FileManager.default.removeItem(at: activeURL)
    }

    public func saveActive(_ context: ActiveSessionContext) throws {
        try encoder.encode(context).write(to: activeURL, options: .atomic)
    }

    public func loadActive() throws -> ActiveSessionContext? {
        guard FileManager.default.fileExists(atPath: activeURL.path) else { return nil }
        return try decoder.decode(ActiveSessionContext.self, from: Data(contentsOf: activeURL))
    }

    public func clearActive() throws {
        try? FileManager.default.removeItem(at: activeURL)
    }
}

public enum ThumbnailStore {
    public static func write(
        jpegData: Data,
        sessionID: UUID,
        containerURL: URL = SharedEnvironment.containerURL()
    ) throws -> String {
        let directory = containerURL
            .appendingPathComponent("thumbnails", isDirectory: true)
            .appendingPathComponent(sessionID.uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let filename = "\(UUID().uuidString).jpg"
        let url = directory.appendingPathComponent(filename)
        try jpegData.write(to: url, options: .atomic)
        #if os(iOS)
        try? FileManager.default.setAttributes(
            [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication],
            ofItemAtPath: url.path
        )
        #endif
        return "thumbnails/\(sessionID.uuidString)/\(filename)"
    }

    @discardableResult
    public static func removeExpired(
        olderThan days: Int = 30,
        now: Date = .now,
        containerURL: URL = SharedEnvironment.containerURL()
    ) throws -> Int {
        let root = containerURL.appendingPathComponent("thumbnails", isDirectory: true)
        guard FileManager.default.fileExists(atPath: root.path) else { return 0 }
        let cutoff = now.addingTimeInterval(-TimeInterval(days * 86_400))
        let resourceKeys: Set<URLResourceKey> = [.contentModificationDateKey, .isRegularFileKey]
        let files = FileManager.default.enumerator(
            at: root,
            includingPropertiesForKeys: Array(resourceKeys)
        )
        var count = 0
        while let url = files?.nextObject() as? URL {
            guard let values = try? url.resourceValues(forKeys: resourceKeys),
                  values.isRegularFile == true,
                  let modified = values.contentModificationDate,
                  modified < cutoff else { continue }
            try? FileManager.default.removeItem(at: url)
            count += 1
        }
        return count
    }
}

extension JSONEncoder {
    static var focusGuard: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.sortedKeys]
        return encoder
    }
}

extension JSONDecoder {
    static var focusGuard: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}
