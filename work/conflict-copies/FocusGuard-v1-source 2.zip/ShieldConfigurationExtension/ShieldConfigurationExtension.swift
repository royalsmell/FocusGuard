import ManagedSettings
import ManagedSettingsUI
import SharedCore
import UIKit

final class ShieldConfigurationExtension: ShieldConfigurationDataSource {
    override func configuration(shielding application: Application) -> ShieldConfiguration {
        makeConfiguration()
    }

    override func configuration(
        shielding application: Application,
        in category: ActivityCategory
    ) -> ShieldConfiguration {
        makeConfiguration()
    }

    override func configuration(shielding webDomain: WebDomain) -> ShieldConfiguration {
        makeConfiguration()
    }

    override func configuration(
        shielding webDomain: WebDomain,
        in category: ActivityCategory
    ) -> ShieldConfiguration {
        makeConfiguration()
    }

    private func makeConfiguration() -> ShieldConfiguration {
        ShieldConfiguration(
            backgroundBlurStyle: .systemUltraThinMaterialDark,
            backgroundColor: UIColor.systemIndigo.withAlphaComponent(0.35),
            icon: UIImage(systemName: "scope"),
            title: .init(text: "先守住这一段时间", color: .white),
            subtitle: .init(text: "你正在完成一个已经答应自己的目标。", color: .white.withAlphaComponent(0.82)),
            primaryButtonLabel: .init(text: "回到专注", color: .white),
            primaryButtonBackgroundColor: .systemIndigo
        )
    }
}

