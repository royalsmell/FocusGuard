import Observation

enum AppTab: Hashable {
    case focus
    case history
    case settings
}

enum SheetDestination: Identifiable, Hashable {
    case activityPicker
    case providerEditor

    var id: String {
        switch self {
        case .activityPicker: "activity-picker"
        case .providerEditor: "provider-editor"
        }
    }
}

@MainActor
@Observable
final class AppRouter {
    var selectedTab: AppTab = .focus
    var presentedSheet: SheetDestination?
}

