import FamilyControls
import Foundation
import Observation
import SharedCore

enum AppModelError: LocalizedError {
    case emptyGoal
    case sessionAlreadyActive
    case missingProvider

    var errorDescription: String? {
        switch self {
        case .emptyGoal: "请先写下这次要完成的目标。"
        case .sessionAlreadyActive: "已有一场专注正在进行。"
        case .missingProvider: "开启 AI 守望前，请先在设置中保存 Provider 和 API Key。"
        }
    }
}

@MainActor
@Observable
final class AppModel {
    var sessions: [FocusSession] = []
    var activeSession: FocusSession?
    var activitySelection = ScreenTimeSharedStore.load()
    var isBusy = false
    var errorMessage: String?

    let providerStore = ProviderStore()
    let screenTime = ScreenTimeController()

    private let repository = SessionRepository()
    private let eventStore = SharedEventStore()
    private let notifications = NotificationService.shared
    private let liveActivity = LiveActivityController()

    func bootstrap() async {
        isBusy = true
        defer { isBusy = false }
        _ = try? await notifications.requestAuthorization()
        _ = try? ThumbnailStore.removeExpired()
        do {
            sessions = try await repository.loadSessions()
            try await importPendingEvents()
            if let context = try await repository.loadActive() {
                if let session = sessions.first(where: { $0.id == context.sessionID }) {
                    activeSession = session
                    if Date() >= context.endsAt {
                        await finishSession(status: .completed, endDate: context.endsAt)
                    }
                } else {
                    screenTime.stop()
                    try await repository.clearActive()
                }
            } else {
                screenTime.stop()
            }
        } catch {
            screenTime.stop()
            errorMessage = error.localizedDescription
        }
    }

    func requestScreenTimeAuthorization() async {
        do {
            try await screenTime.requestAuthorization()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func saveActivitySelection() {
        do {
            try screenTime.saveSelection(activitySelection)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func startSession(goal rawGoal: String, durationMinutes: Int, useAI: Bool) async {
        isBusy = true
        defer { isBusy = false }
        do {
            let goal = rawGoal.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !goal.isEmpty else { throw AppModelError.emptyGoal }
            guard activeSession == nil else { throw AppModelError.sessionAlreadyActive }
            if useAI && !providerStore.hasAPIKey { throw AppModelError.missingProvider }
            if screenTime.authorizationStatus != .approved {
                try await screenTime.requestAuthorization()
            }

            let start = Date()
            let end = start.addingTimeInterval(TimeInterval(durationMinutes * 60))
            let mode: SessionMode = useAI ? .hybridAI : .screenTimeOnly
            let session = FocusSession(
                goal: goal,
                plannedStart: start,
                plannedEnd: end,
                mode: mode
            )
            let context = ActiveSessionContext(
                sessionID: session.id,
                goal: goal,
                startedAt: start,
                endsAt: end,
                mode: mode,
                provider: useAI ? providerStore.configuration : nil
            )

            try await repository.saveActive(context)
            do {
                try screenTime.start(selection: activitySelection, from: start, to: end)
            } catch {
                try? await repository.clearActive()
                throw error
            }
            do {
                try await repository.upsert(session)
            } catch {
                screenTime.stop()
                try? await repository.clearActive()
                throw error
            }
            await notifications.scheduleSessionEnd(sessionID: session.id, goal: goal, at: end)
            liveActivity.start(session: session)
            sessions.insert(session, at: 0)
            activeSession = session
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func stopSession() async {
        await finishSession(status: .cancelled, endDate: Date())
    }

    func refreshActiveSession() async {
        guard let activeSession else { return }
        if Date() >= activeSession.plannedEnd {
            await finishSession(status: .completed, endDate: activeSession.plannedEnd)
        } else {
            await importPendingEventsForActiveSession()
        }
    }

    func deleteAllHistory() async {
        guard activeSession == nil else {
            errorMessage = "请先结束当前专注，再删除历史。"
            return
        }
        do {
            try await repository.deleteAll()
            let container = SharedEnvironment.containerURL()
            let thumbnails = container.appendingPathComponent("thumbnails")
            let events = container.appendingPathComponent("events")
            try? FileManager.default.removeItem(at: thumbnails)
            try? FileManager.default.removeItem(at: events)
            sessions = []
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func session(with id: UUID) -> FocusSession? {
        sessions.first { $0.id == id }
    }

    private func finishSession(status: SessionStatus, endDate: Date) async {
        guard var session = activeSession else { return }
        isBusy = true
        screenTime.stop()
        await notifications.cancelSessionEnd(sessionID: session.id)
        await liveActivity.end(sessionID: session.id)

        let imported = (try? await eventStore.drain(sessionID: session.id)) ?? []
        session.events = merged(session.events, imported)
        session.actualEnd = endDate
        session.status = status
        session.breakdown = SessionMetrics.breakdown(
            events: session.events,
            from: session.plannedStart,
            to: endDate
        )
        if let service = providerStore.makeService() {
            session.summary = try? await service.summarizeSession(.init(session: session))
        }
        if session.summary == nil {
            session.summary = deterministicSummary(for: session)
        }
        try? await repository.upsert(session)
        try? await repository.clearActive()
        activeSession = nil
        replaceSession(session)
        isBusy = false
    }

    private func importPendingEvents() async throws {
        for var session in sessions {
            let pending = try await eventStore.drain(sessionID: session.id)
            guard !pending.isEmpty else { continue }
            session.events = merged(session.events, pending)
            if session.status != .active {
                session.breakdown = SessionMetrics.breakdown(
                    events: session.events,
                    from: session.plannedStart,
                    to: session.effectiveEnd
                )
            }
            try await repository.upsert(session)
            replaceSession(session)
        }
    }

    private func importPendingEventsForActiveSession() async {
        guard var session = activeSession else { return }
        let pending = (try? await eventStore.drain(sessionID: session.id)) ?? []
        guard !pending.isEmpty else { return }
        session.events = merged(session.events, pending)
        activeSession = session
        replaceSession(session)
        try? await repository.upsert(session)
    }

    private func merged(_ existing: [FocusEvent], _ incoming: [FocusEvent]) -> [FocusEvent] {
        var values: [UUID: FocusEvent] = [:]
        for event in existing + incoming {
            values[event.id] = event
        }
        return values.values.sorted { $0.timestamp < $1.timestamp }
    }

    private func replaceSession(_ session: FocusSession) {
        sessions.removeAll { $0.id == session.id }
        sessions.append(session)
        sessions.sort { $0.plannedStart > $1.plannedStart }
    }

    private func deterministicSummary(for session: FocusSession) -> String {
        let coverage = Int((session.breakdown.coverage * 100).rounded())
        let blocked = session.events.filter { $0.source == .screenTimeShield }.count
        return "本次记录覆盖了 \(coverage)% 的会话时间。专注 \(Int(session.breakdown.focusedSeconds / 60)) 分钟，走神 \(Int(session.breakdown.wanderingSeconds / 60)) 分钟，分心 \(Int(session.breakdown.distractedSeconds / 60)) 分钟。期间拦截了 \(blocked) 次分心内容访问；未观测部分不会计入专注时间。"
    }
}
