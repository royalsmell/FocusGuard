import DeviceActivity
import FamilyControls
import Foundation
import ManagedSettings
import SharedCore

@MainActor
final class ScreenTimeController {
    private let activityCenter = DeviceActivityCenter()
    private let activityName = DeviceActivityName(SharedConstants.focusActivityName)

    var authorizationStatus: AuthorizationStatus {
        AuthorizationCenter.shared.authorizationStatus
    }

    func requestAuthorization() async throws {
        try await AuthorizationCenter.shared.requestAuthorization(for: .individual)
    }

    func saveSelection(_ selection: FamilyActivitySelection) throws {
        try ScreenTimeSharedStore.save(selection)
    }

    func start(selection: FamilyActivitySelection, from start: Date, to end: Date) throws {
        try saveSelection(selection)
        ScreenTimeSharedStore.applyShield(for: selection)

        let calendar = Calendar.current
        let components: Set<Calendar.Component> = [.era, .year, .month, .day, .hour, .minute, .second]
        let monitoredStart = min(end.addingTimeInterval(-1), start.addingTimeInterval(5))
        let schedule = DeviceActivitySchedule(
            intervalStart: calendar.dateComponents(components, from: monitoredStart),
            intervalEnd: calendar.dateComponents(components, from: end),
            repeats: false
        )
        do {
            try activityCenter.startMonitoring(activityName, during: schedule)
        } catch {
            ScreenTimeSharedStore.clearShield()
            throw error
        }
    }

    func stop() {
        activityCenter.stopMonitoring([activityName])
        ScreenTimeSharedStore.clearShield()
    }
}
