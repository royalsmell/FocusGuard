import Foundation
import Observation
import SharedCore

@MainActor
@Observable
final class ProviderStore {
    private(set) var configuration: ProviderConfig
    private(set) var hasAPIKey = false

    private let defaults: UserDefaults

    init() {
        self.defaults = UserDefaults(suiteName: SharedConstants.appGroupIdentifier) ?? .standard
        if let data = defaults.data(forKey: SharedConstants.providerDefaultsKey),
           let value = try? JSONDecoder().decode(ProviderConfig.self, from: data) {
            self.configuration = value
        } else {
            self.configuration = .suggested
        }
        refreshKeyStatus()
    }

    func save(configuration: ProviderConfig, apiKey: String?) throws {
        if configuration.id != self.configuration.id {
            try? KeychainStore.delete(
                account: self.configuration.id.uuidString,
                accessGroup: keychainAccessGroup
            )
        }
        self.configuration = configuration
        defaults.set(try JSONEncoder().encode(configuration), forKey: SharedConstants.providerDefaultsKey)
        if let apiKey, !apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            try KeychainStore.save(
                apiKey.trimmingCharacters(in: .whitespacesAndNewlines),
                account: configuration.id.uuidString,
                accessGroup: keychainAccessGroup
            )
        }
        refreshKeyStatus()
    }

    func loadAPIKey() -> String? {
        try? KeychainStore.load(
            account: configuration.id.uuidString,
            accessGroup: keychainAccessGroup
        )
    }

    func deleteAPIKey() throws {
        try KeychainStore.delete(
            account: configuration.id.uuidString,
            accessGroup: keychainAccessGroup
        )
        refreshKeyStatus()
    }

    func makeService() -> OpenAICompatibleVisionService? {
        guard let key = loadAPIKey(), !key.isEmpty else { return nil }
        return OpenAICompatibleVisionService(provider: configuration, apiKey: key)
    }

    private func refreshKeyStatus() {
        hasAPIKey = !(loadAPIKey() ?? "").isEmpty
    }

    private var keychainAccessGroup: String? {
        Bundle.main.object(forInfoDictionaryKey: "FocusGuardKeychainAccessGroup") as? String
    }
}

