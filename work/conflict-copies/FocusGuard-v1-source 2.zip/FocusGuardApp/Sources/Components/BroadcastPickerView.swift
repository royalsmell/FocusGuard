import ReplayKit
import SharedCore
import SwiftUI

struct BroadcastPickerView: UIViewRepresentable {
    func makeUIView(context: Context) -> RPSystemBroadcastPickerView {
        let picker = RPSystemBroadcastPickerView(frame: .zero)
        picker.preferredExtension = SharedConstants.broadcastExtensionBundleIdentifier
        picker.showsMicrophoneButton = false
        picker.tintColor = .systemIndigo
        return picker
    }

    func updateUIView(_ uiView: RPSystemBroadcastPickerView, context: Context) {}
}

