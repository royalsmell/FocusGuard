import FamilyControls
import SharedCore
import SwiftUI

struct SettingsView: View {
    @Environment(AppModel.self) private var model
    @Environment(AppRouter.self) private var router
    @State private var confirmDelete = false

    var body: some View {
        List {
            Section("AI Provider") {
                Button {
                    router.presentedSheet = .providerEditor
                } label: {
                    HStack {
                        Label(model.providerStore.configuration.name, systemImage: "sparkles")
                        Spacer()
                        Text(model.providerStore.hasAPIKey ? "已配置" : "需要密钥")
                            .foregroundStyle(model.providerStore.hasAPIKey ? .green : .orange)
                        Image(systemName: "chevron.right")
                            .foregroundStyle(.tertiary)
                    }
                }
                .foregroundStyle(.primary)
            }

            Section("权限") {
                HStack {
                    Label("Screen Time", systemImage: "shield")
                    Spacer()
                    Text(authorizationText)
                        .foregroundStyle(.secondary)
                }
                Button("重新请求 Screen Time 授权") {
                    Task { await model.requestScreenTimeAuthorization() }
                }
            } footer: {
                Text("系统不会向本 App 暴露你选择的应用名称，只提供不可读的授权令牌。")
            }

            Section("隐私与数据") {
                Label("原始屏幕帧不会写入磁盘", systemImage: "lock.shield")
                Label("仅保留确认分心的 320px 缩略图", systemImage: "photo")
                Label("缩略图 30 天后自动清理", systemImage: "trash")
                Button("删除全部历史和缩略图", role: .destructive) {
                    confirmDelete = true
                }
            }

            Section("关于") {
                LabeledContent("版本", value: "1.0.0")
                Text("专注守望是独立实现的个人专注工具，不包含 Vigil 的源码或素材。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("设置")
        .confirmationDialog("确定删除全部历史吗？", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("删除全部数据", role: .destructive) {
                Task { await model.deleteAllHistory() }
            }
            Button("取消", role: .cancel) {}
        }
    }

    private var authorizationText: String {
        switch model.screenTime.authorizationStatus {
        case .approved: "已授权"
        case .denied: "已拒绝"
        case .notDetermined: "未请求"
        @unknown default: "未知"
        }
    }
}

