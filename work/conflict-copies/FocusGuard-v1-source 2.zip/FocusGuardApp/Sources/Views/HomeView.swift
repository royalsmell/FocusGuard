import FamilyControls
import SharedCore
import SwiftUI

struct HomeView: View {
    @Environment(AppModel.self) private var model
    @Environment(AppRouter.self) private var router
    @State private var goal = ""
    @State private var durationMinutes = 25
    @State private var useAI = true

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                if let session = model.activeSession {
                    ActiveSessionCard(session: session)
                } else {
                    newSessionContent
                }
            }
            .padding()
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("专注守望")
        .toolbar {
            if model.isBusy {
                ToolbarItem(placement: .topBarTrailing) { ProgressView() }
            }
        }
    }

    private var newSessionContent: some View {
        VStack(spacing: 18) {
            VStack(alignment: .leading, spacing: 10) {
                Label("这次要完成什么？", systemImage: "text.cursor")
                    .font(.headline)
                TextField("例如：完成产品需求文档第一稿", text: $goal, axis: .vertical)
                    .textFieldStyle(.roundedBorder)
                    .lineLimit(2...4)
                    .accessibilityIdentifier("goal-field")
            }
            .focusCard()

            VStack(alignment: .leading, spacing: 12) {
                Label("专注时长", systemImage: "timer")
                    .font(.headline)
                HStack {
                    ForEach([10, 15, 25, 45, 60], id: \.self) { minutes in
                        Button("\(minutes)") { durationMinutes = minutes }
                            .buttonStyle(DurationButtonStyle(selected: durationMinutes == minutes))
                    }
                }
                .frame(maxWidth: .infinity)
            }
            .focusCard()

            Button {
                router.presentedSheet = .activityPicker
            } label: {
                HStack {
                    Label("分心内容屏蔽", systemImage: "shield")
                    Spacer()
                    Text(selectionSummary)
                        .foregroundStyle(.secondary)
                    Image(systemName: "chevron.right")
                        .foregroundStyle(.tertiary)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .focusCard()

            VStack(alignment: .leading, spacing: 8) {
                Toggle(isOn: $useAI) {
                    Label("AI 屏幕守望", systemImage: "eye")
                        .font(.headline)
                }
                Text(useAI
                     ? "开始后请通过系统按钮主动开启屏幕广播。"
                     : "仅使用 Screen Time 屏蔽，不分析屏幕内容。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                if useAI && !model.providerStore.hasAPIKey {
                    Button("配置 AI Provider") { router.presentedSheet = .providerEditor }
                        .font(.footnote.bold())
                }
            }
            .focusCard()

            Button {
                Task {
                    await model.startSession(
                        goal: goal,
                        durationMinutes: durationMinutes,
                        useAI: useAI
                    )
                }
            } label: {
                Label("开始 \(durationMinutes) 分钟", systemImage: "scope")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
            }
            .buttonStyle(.borderedProminent)
            .tint(.indigo)
            .disabled(model.isBusy || goal.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            .accessibilityIdentifier("start-session")
        }
    }

    private var selectionSummary: String {
        let selection = model.activitySelection
        let count = selection.applicationTokens.count + selection.categoryTokens.count + selection.webDomainTokens.count
        return count == 0 ? "未选择" : "已选 \(count) 项"
    }
}

private struct ActiveSessionCard: View {
    @Environment(AppModel.self) private var model
    let session: FocusSession

    var body: some View {
        VStack(spacing: 22) {
            Image(systemName: "scope")
                .font(.system(size: 42, weight: .semibold))
                .foregroundStyle(.indigo)
            Text(session.goal)
                .font(.title2.bold())
                .multilineTextAlignment(.center)
            TimelineView(.periodic(from: .now, by: 1)) { context in
                Text(remainingText(at: context.date))
                    .font(.system(size: 54, weight: .semibold, design: .rounded).monospacedDigit())
            }

            if session.mode == .hybridAI {
                VStack(spacing: 10) {
                    BroadcastPickerView()
                        .frame(width: 54, height: 54)
                        .accessibilityLabel("开启或停止 AI 屏幕广播")
                    Text("点按上方系统按钮开启屏幕广播")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    BroadcastHealthView(session: session)
                }
            } else {
                Label("Screen Time 屏蔽中", systemImage: "shield.checkered")
                    .foregroundStyle(.green)
            }

            if let latest = session.events.last(where: { $0.source == .visionAI }) {
                StatusPill(level: latest.level, text: latest.reason)
            }

            Button("提前结束", role: .destructive) {
                Task { await model.stopSession() }
            }
            .buttonStyle(.bordered)
            .disabled(model.isBusy)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 34)
        .focusCard()
    }

    private func remainingText(at date: Date) -> String {
        let seconds = max(0, Int(session.plannedEnd.timeIntervalSince(date)))
        return String(format: "%02d:%02d", seconds / 60, seconds % 60)
    }
}

private struct BroadcastHealthView: View {
    let session: FocusSession

    var body: some View {
        Label(status.text, systemImage: status.icon)
            .font(.footnote.bold())
            .foregroundStyle(status.color)
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(status.color.opacity(0.1), in: Capsule())
    }

    private var status: (text: String, icon: String, color: Color) {
        let broadcastEvents = session.events.filter { $0.source == .broadcast }
        if let latest = broadcastEvents.last, latest.reason.contains("停止") {
            return ("广播已停止 · Screen Time 继续", "record.circle", .orange)
        }
        if let latestVision = session.events.last(where: { $0.source == .visionAI }),
           Date().timeIntervalSince(latestVision.timestamp) < 90 {
            return ("AI 正在观测", "eye.fill", .green)
        }
        if broadcastEvents.contains(where: { $0.reason.contains("开始") || $0.reason.contains("恢复") }) {
            return ("广播已连接 · 等待下一帧", "wave.3.right", .indigo)
        }
        return ("等待开启屏幕广播", "record.circle", .secondary)
    }
}

private struct DurationButtonStyle: ButtonStyle {
    let selected: Bool

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.bold())
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
            .background(selected ? Color.indigo : Color.secondary.opacity(0.1), in: .rect(cornerRadius: 12))
            .foregroundStyle(selected ? .white : .primary)
            .opacity(configuration.isPressed ? 0.7 : 1)
    }
}
