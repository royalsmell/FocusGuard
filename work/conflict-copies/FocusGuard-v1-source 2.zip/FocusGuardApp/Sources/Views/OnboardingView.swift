import SwiftUI

struct OnboardingView: View {
    @Environment(AppModel.self) private var model
    @State private var page = 0
    let onComplete: () -> Void

    var body: some View {
        VStack(spacing: 24) {
            Spacer()
            Image(systemName: pageIcon)
                .font(.system(size: 62, weight: .semibold))
                .foregroundStyle(.indigo)
                .contentTransition(.symbolEffect(.replace))
            Text(pageTitle)
                .font(.largeTitle.bold())
                .multilineTextAlignment(.center)
            Text(pageBody)
                .font(.title3)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 28)
            Spacer()
            HStack(spacing: 7) {
                ForEach(0..<3) { index in
                    Capsule()
                        .fill(index == page ? Color.indigo : Color.secondary.opacity(0.25))
                        .frame(width: index == page ? 24 : 8, height: 8)
                }
            }
            Button {
                Task { await advance() }
            } label: {
                Text(page == 2 ? "开始使用" : "继续")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
            }
            .buttonStyle(.borderedProminent)
            .tint(.indigo)
            .padding(.horizontal, 24)
        }
        .padding(.vertical, 32)
        .background(Color(.systemGroupedBackground))
    }

    private func advance() async {
        if page == 1 {
            await model.requestScreenTimeAuthorization()
        }
        if page < 2 {
            withAnimation { page += 1 }
        } else {
            onComplete()
        }
    }

    private var pageIcon: String {
        ["scope", "shield.lefthalf.filled", "record.circle"][page]
    }

    private var pageTitle: String {
        ["守住真正重要的事", "由系统帮你挡住分心", "AI 守望由你主动开启"][page]
    }

    private var pageBody: String {
        [
            "写下一个目标，选择一段时间，然后只管开始。",
            "专注期间，Screen Time 会遮挡你选择的应用和网站；授权内容不会向我们公开。",
            "需要理解屏幕内容时，请手动开启系统屏幕广播。原始画面不会保存，只保留确认分心事件的缩略图。"
        ][page]
    }
}

