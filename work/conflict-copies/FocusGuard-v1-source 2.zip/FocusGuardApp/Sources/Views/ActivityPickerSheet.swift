import FamilyControls
import SwiftUI

struct ActivityPickerSheet: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(AppModel.self) private var model

    var body: some View {
        @Bindable var model = model
        FamilyActivityPicker(selection: $model.activitySelection)
            .navigationTitle("选择分心内容")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") {
                        model.saveActivitySelection()
                        dismiss()
                    }
                }
            }
    }
}

