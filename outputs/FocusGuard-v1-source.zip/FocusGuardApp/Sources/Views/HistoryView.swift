import SharedCore
import SwiftUI

struct HistoryView: View {
    @Environment(AppModel.self) private var model
    @State private var page = HistoryPage.records

    var body: some View {
        VStack(spacing: 0) {
            Picker("历史页面", selection: $page) {
                Text("记录").tag(HistoryPage.records)
                Text("统计").tag(HistoryPage.analytics)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal)
            .padding(.vertical, 8)

            switch page {
            case .records: recordsView
            case .analytics: HistoryAnalyticsView(sessions: completedSessions)
            }
        }
        .navigationTitle("专注历史")
        .navigationDestination(for: UUID.self) { id in
            if let session = model.session(with: id) { SessionDetailView(session: session) }
        }
    }

    @ViewBuilder
    private var recordsView: some View {
        if completedSessions.isEmpty {
            ContentUnavailableView(
                "还没有专注记录",
                systemImage: "clock.arrow.circlepath",
                description: Text("完成第一场专注后，复盘会出现在这里。")
            )
        } else {
            List(completedSessions) { session in
                NavigationLink(value: session.id) { SessionRow(session: session) }
                    .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                        Button("删除", role: .destructive) {
                            Task { await model.deleteSession(id: session.id) }
                        }
                    }
            }
            .listStyle(.insetGrouped)
        }
    }

    private var completedSessions: [FocusSession] {
        model.sessions.filter { $0.status != .active }
    }
}

private enum HistoryPage { case records, analytics }

private struct HistoryAnalyticsView: View {
    let sessions: [FocusSession]
    @State private var scope = AnalyticsScope.session

    private var report: AnalyticsReport { FocusAnalytics.report(sessions: sessions, scope: scope) }

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                Picker("统计周期", selection: $scope) {
                    Text("每次").tag(AnalyticsScope.session)
                    Text("日").tag(AnalyticsScope.day)
                    Text("周").tag(AnalyticsScope.week)
                    Text("年").tag(AnalyticsScope.year)
                }
                .pickerStyle(.segmented)

                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                    SummaryMetric(title: "会话数", value: "\(report.summary.sessionCount)")
                    SummaryMetric(title: "完成率", value: percent(report.summary.completionRate))
                    SummaryMetric(title: "总专注", value: duration(report.summary.focusedSeconds))
                    SummaryMetric(title: "平均覆盖率", value: percent(report.summary.averageCoverage))
                }

                if report.rows.isEmpty {
                    ContentUnavailableView("暂无统计", systemImage: "chart.bar.xaxis")
                        .padding(.top, 30)
                } else {
                    AnalyticsTable(scope: scope, rows: report.rows)
                }
            }
            .padding()
        }
        .background(Color(.systemGroupedBackground))
    }
}

private struct SummaryMetric: View {
    let title: String
    let value: String

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.title3.bold()).monospacedDigit()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(.background, in: .rect(cornerRadius: 14))
    }
}

private struct AnalyticsTable: View {
    let scope: AnalyticsScope
    let rows: [AnalyticsRow]

    var body: some View {
        ScrollView(.horizontal) {
            Grid(alignment: .leading, horizontalSpacing: 16, verticalSpacing: 0) {
                GridRow { headers }
                    .font(.caption.bold())
                    .foregroundStyle(.secondary)
                Divider().gridCellColumns(scope == .session ? 9 : 10)
                ForEach(rows) { row in
                    GridRow { cells(row) }
                        .font(.caption)
                        .padding(.vertical, 10)
                    Divider().gridCellColumns(scope == .session ? 9 : 10)
                }
            }
            .padding()
            .background(.background, in: .rect(cornerRadius: 14))
        }
    }

    @ViewBuilder private var headers: some View {
        if scope == .session {
            tableText("日期", 115); tableText("任务", 180); tableText("状态", 52)
            tableText("实际时长", 75); tableText("专注", 62); tableText("走神", 62)
            tableText("分心", 62); tableText("未观测", 62); tableText("覆盖率", 58)
        } else {
            tableText("周期", 110); tableText("会话数", 52); tableText("完成率", 58)
            tableText("总时长", 70); tableText("专注", 62); tableText("走神", 62)
            tableText("分心", 62); tableText("未观测", 62); tableText("覆盖率", 58)
        }
    }

    @ViewBuilder private func cells(_ row: AnalyticsRow) -> some View {
        if scope == .session {
            tableText(row.periodStart.formatted(date: .numeric, time: .shortened), 115)
            tableText(row.title, 180, lineLimit: 2)
            tableText(row.status == .completed ? "完成" : "提前结束", 52)
        } else {
            tableText(row.title, 110)
            tableText("\(row.sessionCount)", 52)
            tableText(percent(row.completionRate), 58)
        }
        tableText(duration(row.totalSeconds), 75)
        tableText(duration(row.breakdown.focusedSeconds), 62)
        tableText(duration(row.breakdown.wanderingSeconds), 62)
        tableText(duration(row.breakdown.distractedSeconds), 62)
        tableText(duration(row.breakdown.unknownSeconds), 62)
        tableText(percent(row.coverage), 58)
    }

    private func tableText(_ value: String, _ width: CGFloat, lineLimit: Int = 1) -> some View {
        Text(value).lineLimit(lineLimit).frame(width: width, alignment: .leading)
    }
}

private struct SessionRow: View {
    let session: FocusSession

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(session.goal).font(.headline).lineLimit(2)
            HStack(spacing: 12) {
                Label(duration(session.duration), systemImage: "timer")
                Label(session.plannedStart.formatted(date: .abbreviated, time: .shortened), systemImage: "calendar")
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            MetricBar(breakdown: session.breakdown).frame(height: 7)
        }
        .padding(.vertical, 5)
    }
}

private func duration(_ seconds: TimeInterval) -> String {
    let totalMinutes = max(0, Int(seconds / 60))
    if totalMinutes >= 60 { return "\(totalMinutes / 60)时\(totalMinutes % 60)分" }
    return "\(totalMinutes)分"
}

private func percent(_ value: Double) -> String {
    "\(Int((min(max(value, 0), 1) * 100).rounded()))%"
}
