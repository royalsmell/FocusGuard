import SharedCore
import SwiftUI

struct SettingsView: View {
    @Environment(AppModel.self) private var model
    @Environment(AppRouter.self) private var router
    @State private var confirmDelete = false

    var body: some View {
        List {
            Section("AI Provider") {
                Button {
                    router.presentedSheet = .providerEditor
                } label: {
                    HStack {
                        Label(model.providerStore.configuration.name, systemImage: "sparkles")
                        Spacer()
                        Text(model.providerStore.hasAPIKey ? "已配置" : "需要密钥")
                            .foregroundStyle(model.providerStore.hasAPIKey ? .green : .orange)
                        Image(systemName: "chevron.right")
                            .foregroundStyle(.tertiary)
                    }
                }
                .foregroundStyle(.primary)
            }

            Section {
                ForEach(model.durationPreferences.quickMinutes.indices, id: \.self) { index in
                    Button {
                        router.presentedSheet = .durationPresetEditor(index: index)
                    } label: {
                        HStack {
                            Text("快捷时长 \(index + 1)")
                            Spacer()
                            Text(FocusDurationText.full(minutes: model.durationPreferences.quickMinutes[index]))
                                .foregroundStyle(.secondary)
                            Image(systemName: "chevron.right")
                                .foregroundStyle(.tertiary)
                        }
                    }
                    .foregroundStyle(.primary)
                }
            } header: {
                Text("快捷时长")
            } footer: {
                Text("首页固定显示五个快捷时长；每项可设置为 1 分钟到 23 小时 59 分钟。")
            }

            Section {
                Toggle("走神时静默提醒", isOn: Binding(
                    get: { model.reminderPreferences.silentWanderingEnabled },
                    set: {
                        model.reminderPreferences.silentWanderingEnabled = $0
                        model.saveReminderPreferences()
                    }
                ))
                Toggle("分心时有声提醒", isOn: Binding(
                    get: { model.reminderPreferences.audibleDistractionEnabled },
                    set: {
                        model.reminderPreferences.audibleDistractionEnabled = $0
                        model.saveReminderPreferences()
                    }
                ))
            } header: {
                Text("提醒")
            } footer: {
                Text("连续三次走神触发静默提醒；连续两次分心触发有声提醒。网络失败、未知或低置信度不会提醒。")
            }

            Section("隐私与数据") {
                Label("原始屏幕帧不会写入磁盘", systemImage: "lock.shield")
                Label("仅保留确认分心的 320px 缩略图", systemImage: "photo")
                Label("缩略图 30 天后自动清理", systemImage: "trash")
                Button("删除全部历史和缩略图", role: .destructive) {
                    confirmDelete = true
                }
            }

            Section("关于") {
                LabeledContent("版本", value: appVersion)
                Text("专注守望是独立实现的个人专注工具，不包含 Vigil 的源码或素材。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("设置")
        .confirmationDialog("确定删除全部历史吗？", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("删除全部数据", role: .destructive) {
                Task { await model.deleteAllHistory() }
            }
            Button("取消", role: .cancel) {}
        }
    }

    private var appVersion: String {
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String
        return [version, build.map { "(\($0))" }].compactMap { $0 }.joined(separator: " ")
    }
}
