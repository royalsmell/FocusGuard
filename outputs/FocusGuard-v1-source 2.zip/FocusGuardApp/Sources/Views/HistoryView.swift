import SharedCore
import SwiftUI

struct HistoryView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        Group {
            if model.sessions.filter({ $0.status != .active }).isEmpty {
                ContentUnavailableView(
                    "还没有专注记录",
                    systemImage: "clock.arrow.circlepath",
                    description: Text("完成第一场专注后，复盘会出现在这里。")
                )
            } else {
                List(model.sessions.filter { $0.status != .active }) { session in
                    NavigationLink(value: session.id) {
                        SessionRow(session: session)
                    }
                    .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                        Button("删除", role: .destructive) {
                            Task { await model.deleteSession(id: session.id) }
                        }
                    }
                }
                .listStyle(.insetGrouped)
                .navigationDestination(for: UUID.self) { id in
                    if let session = model.session(with: id) {
                        SessionDetailView(session: session)
                    }
                }
            }
        }
        .navigationTitle("专注历史")
    }
}

private struct SessionRow: View {
    let session: FocusSession

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(session.goal)
                .font(.headline)
                .lineLimit(2)
            HStack(spacing: 12) {
                Label(durationText, systemImage: "timer")
                Label(session.plannedStart.formatted(date: .abbreviated, time: .shortened), systemImage: "calendar")
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            MetricBar(breakdown: session.breakdown)
                .frame(height: 7)
        }
        .padding(.vertical, 5)
    }

    private var durationText: String {
        FocusDurationText.full(minutes: max(0, Int(session.duration / 60)))
    }
}
